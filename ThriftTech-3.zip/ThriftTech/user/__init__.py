from flask import Blueprint

user_bp = Blueprint('user', __name__, template_folder='../templates')

from . import routes  # Import routes and functions from user.py